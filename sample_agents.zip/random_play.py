# From: http://www.rpscontest.com/submit

import random
output = random.choice(["R", "P", "S"])
