# From: http://www.rpscontest.com/submit

output = "R"
